package Towerofhanoi;

public class Main {

    public static void main(String[] args) {
        System.out.println("Tower of Hanoi\n\n\n ");
        Logic_Output lg = new Logic_Output();
    }
}
