package Towerofhanoi;

public class Ring {
    private int numberOfRing;

    public Ring(int numberOfRing) {
        this.numberOfRing=numberOfRing;

    }
    public int getNumberOfRing() {
        return this.numberOfRing;
    }
}

