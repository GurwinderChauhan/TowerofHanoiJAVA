package Towerofhanoi;

public class Tower {
    private String nameOfTOwer;

    public Tower(String nameOfTOwer) {
        this.nameOfTOwer = nameOfTOwer;
    }

    public String getNameOfTOwer() {
        return nameOfTOwer;
    }

}
